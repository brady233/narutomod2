"""Generates lang, models, recipes and damage types from Jutsus.java. Run: python3 tools/make_resources.py"""
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.join(HERE, "..")
RES = os.path.join(PROJECT, "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", "shinobiarts")
DATA = os.path.join(RES, "data", "shinobiarts")
MODID = "shinobiarts"

NATURES = ["fire", "water", "wind", "lightning", "earth"]
NATURE_NAMES = {"fire": "Fire Release", "water": "Water Release", "wind": "Wind Release",
                "lightning": "Lightning Release", "earth": "Earth Release", "none": "Non-elemental"}
CATALYST = {"fire": "minecraft:blaze_powder", "water": "minecraft:prismarine_shard", "wind": "minecraft:feather",
            "lightning": "minecraft:copper_ingot", "earth": "minecraft:clay_ball"}
TIER_ITEM = {1: None, 2: "minecraft:gold_ingot", 3: "minecraft:diamond"}

JUTSU_TEXT = {
    "fireball": ("Fire Release: Great Fireball", "Launches a huge ball of fire that bursts into flames on impact."),
    "phoenix_flower": ("Fire Release: Phoenix Flower", "Fires a fan of five small fireballs that set targets ablaze."),
    "fire_annihilation": ("Fire Release: Great Fire Annihilation", "Breathes a sea of fire across a wide cone in front of you."),
    "water_bullet": ("Water Release: Water Bullet", "A fast, hard-hitting shot of water that knocks enemies back."),
    "water_prison": ("Water Release: Water Prison", "Traps the creature you're looking at in water, holding it nearly still."),
    "water_dragon": ("Water Release: Water Dragon", "A surging dragon of water that crashes down on everything near its impact."),
    "gale_palm": ("Wind Release: Gale Palm", "A blast of wind that throws enemies back and turns aside projectiles."),
    "vacuum_blade": ("Wind Release: Vacuum Blade", "An invisible blade of wind that cuts through every enemy in a line."),
    "great_breakthrough": ("Wind Release: Great Breakthrough", "A colossal gust that flattens plants and hurls everything in front of you away."),
    "lightning_armor": ("Lightning Release: Lightning Armor", "Coats your body in lightning: faster movement, attacks and mining for 20 seconds."),
    "chidori": ("Chidori", "Dash to the enemy you're looking at and strike with a crackling blade of lightning."),
    "thunder_strike": ("Lightning Release: Thunder Strike", "Calls down a lightning bolt where you're looking."),
    "earth_wall": ("Earth Release: Earth Wall", "Raises a wall of earth in front of you. It crumbles after about 15 seconds."),
    "rock_armor": ("Earth Release: Rock Armor", "Hardens your body like stone for 20 seconds: strong damage resistance, but slower."),
    "earth_spikes": ("Earth Release: Rising Spikes", "The ground erupts where you're looking, launching enemies into the air."),
    "substitution": ("Substitution Jutsu", "For 6 seconds, the next attack hits a log instead and you vanish a few blocks away."),
    "body_flicker": ("Body Flicker", "Move in a blur to the spot you're looking at (up to 16 blocks)."),
    "shadow_clone": ("Shadow Clone Jutsu", "Creates solid copies of yourself that fight beside you for 30 seconds. Any hit dispels them."),
    "rasengan": ("Rasengan", "Spin chakra into a sphere in your hand. Your next punch deals huge damage and sends the target flying."),
    "shadow_possession": ("Shadow Possession", "Stretches your shadow to bind a target in place for 6 seconds. You're slowed while holding it."),
    "palm_rotation": ("Eight Trigrams Palm Rotation", "Spin chakra around you to repel everything nearby and block all attacks for a moment."),
    "amaterasu": ("Amaterasu", "Black flames that burn a target for 10 seconds and can't be put out. Needs an active Sharingan."),
}

# Shapeless recipe ingredients for each jutsu scroll (besides the blank scroll).
SPECIAL_RECIPES = {
    "substitution": [{"tag": "minecraft:logs"}, "minecraft:lapis_lazuli"],
    "body_flicker": ["minecraft:feather", "minecraft:sugar"],
    "shadow_clone": ["minecraft:lapis_lazuli", "minecraft:lapis_lazuli", "minecraft:gold_ingot"],
    "rasengan": ["minecraft:lapis_lazuli", "minecraft:lapis_lazuli", "minecraft:diamond"],
    "shadow_possession": ["minecraft:ink_sac", "minecraft:ink_sac", "minecraft:gold_ingot"],
    "palm_rotation": ["minecraft:quartz", "minecraft:quartz", "minecraft:gold_ingot"],
    "amaterasu": ["minecraft:ink_sac", "minecraft:blaze_powder", "minecraft:ender_eye", "minecraft:diamond"],
}


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def parse_jutsus():
    src = open(os.path.join(PROJECT, "src", "main", "java", "com", "shinobiarts", "jutsu", "Jutsus.java")).read()
    out = []
    for m in re.finditer(r'reg\("(\w+)",\s*(\w+),\s*(null|Clan\.\w+),\s*(\d)', src):
        jid, nature, clan, tier = m.group(1), m.group(2).lower(), m.group(3), int(m.group(4))
        clan = None if clan == "null" else clan.split(".")[1].lower()
        out.append({"id": jid, "nature": nature, "clan": clan, "tier": tier})
    return out


def ingredient(spec):
    return spec if isinstance(spec, dict) else {"item": spec}


def shapeless(name, ingredients, result, count=1, category="misc"):
    write_json(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shapeless",
        "category": category,
        "ingredients": [ingredient(i) for i in ingredients],
        "result": {"item": result, "count": count},
    })
    return tuple(sorted(json.dumps(ingredient(i), sort_keys=True) for i in ingredients))


def shaped(name, pattern, key, result, count=1, category="equipment"):
    write_json(os.path.join(DATA, "recipes", name + ".json"), {
        "type": "minecraft:crafting_shaped",
        "category": category,
        "pattern": pattern,
        "key": {k: ingredient(v) for k, v in key.items()},
        "result": {"item": result, "count": count},
    })


def item_model(name, texture, parent="minecraft:item/generated"):
    write_json(os.path.join(ASSETS, "models", "item", name + ".json"),
               {"parent": parent, "textures": {"layer0": MODID + ":item/" + texture}})


def short_name(full):
    return full.split(": ", 1)[1] if ": " in full else full


def main():
    jutsus = parse_jutsus()
    assert len(jutsus) == len(JUTSU_TEXT), (len(jutsus), sorted(set(j["id"] for j in jutsus) ^ set(JUTSU_TEXT)))

    lang = {
        "itemGroup.shinobiarts": "Shinobi Arts",
        "item.shinobiarts.kunai": "Kunai",
        "item.shinobiarts.shuriken": "Shuriken",
        "item.shinobiarts.explosive_tag": "Explosive Tag",
        "item.shinobiarts.chakra_pill": "Chakra Pill",
        "item.shinobiarts.chakra_paper": "Chakra Paper",
        "item.shinobiarts.blank_scroll": "Blank Scroll",
        "block.shinobiarts.earth_wall": "Earth Wall",
        "entity.shinobiarts.jutsu_projectile": "Jutsu",
        "entity.shinobiarts.thrown_tool": "Thrown Weapon",
        "entity.shinobiarts.explosive_tag": "Explosive Tag",
        "entity.shinobiarts.shadow_clone": "Shadow Clone",
        "effect.shinobiarts.amaterasu": "Amaterasu",

        "clan.shinobiarts.none": "Clanless",
        "clan.shinobiarts.uchiha": "Uchiha",
        "clan.shinobiarts.hyuga": "Hyuga",
        "clan.shinobiarts.uzumaki": "Uzumaki",
        "clan.shinobiarts.nara": "Nara",
        "dojutsu.shinobiarts.uchiha": "Sharingan",
        "dojutsu.shinobiarts.hyuga": "Byakugan",
        "dojutsu.shinobiarts.none": "Dojutsu",
        "dojutsu.shinobiarts.uzumaki": "Dojutsu",
        "dojutsu.shinobiarts.nara": "Dojutsu",

        "key.categories.shinobiarts": "Shinobi Arts",
        "key.shinobiarts.cast": "Cast jutsu",
        "key.shinobiarts.next": "Next jutsu",
        "key.shinobiarts.prev": "Previous jutsu",
        "key.shinobiarts.dojutsu": "Toggle eye technique",
        "key.shinobiarts.charge": "Charge chakra (hold)",
        "key.shinobiarts.menu": "Ninja menu",

        "hud.shinobiarts.chakra": "Chakra %s / %s",
        "hud.shinobiarts.ready": " Ready",
        "hud.shinobiarts.low_chakra": " Low chakra",
        "hud.shinobiarts.no_jutsu": "No jutsu selected. Press %s for the menu.",
        "hud.shinobiarts.charging": "Charging chakra...",
        "hud.shinobiarts.rasengan": "Rasengan charged",
        "hud.shinobiarts.substitution": "Substitution set",

        "screen.shinobiarts.title": "Ninja Info",
        "screen.shinobiarts.clan": "Clan: %s",
        "screen.shinobiarts.affinity": "Affinity: %s",
        "screen.shinobiarts.affinity_unknown": "Unknown (use Chakra Paper)",
        "screen.shinobiarts.natures": "Natures: %s",
        "screen.shinobiarts.chakra": "Chakra: %s / %s",
        "screen.shinobiarts.no_jutsu": "You haven't learned any jutsu yet.",

        "tooltip.shinobiarts.clan_only": "Clan technique: %s",
        "tooltip.shinobiarts.nature": "Nature: %s",
        "tooltip.shinobiarts.cost": "Chakra: %s  Cooldown: %ss",
        "tooltip.shinobiarts.requires_chakra": "Requires %s max chakra",
        "tooltip.shinobiarts.needs_dojutsu": "Requires an active Sharingan",
        "tooltip.shinobiarts.known": "Already learned",
        "tooltip.shinobiarts.right_click_learn": "Right-click to learn",
        "tooltip.shinobiarts.nature_scroll": "Unlocks %s jutsu",
        "tooltip.shinobiarts.nature_scroll_req": "You must know your affinity first (use Chakra Paper).",
        "tooltip.shinobiarts.chakra_paper": "Right-click to discover your nature affinity.",
        "tooltip.shinobiarts.chakra_pill": "Restores %s chakra",
        "tooltip.shinobiarts.throwable": "Right-click to throw",
        "tooltip.shinobiarts.explosive_tag": "Throw it: sticks to blocks and explodes after 2 seconds.",

        "message.shinobiarts.no_target": "No target in sight.",
        "message.shinobiarts.no_room": "There's no room for that here.",
        "message.shinobiarts.no_jutsu": "You haven't learned any jutsu. Read a jutsu scroll first.",
        "message.shinobiarts.cooldown": "%s is recharging (%ss)",
        "message.shinobiarts.needs_dojutsu": "This jutsu needs your %s active.",
        "message.shinobiarts.not_enough_chakra": "Not enough chakra (%s / %s)",
        "message.shinobiarts.sharingan_copy": "Your Sharingan copied %s!",
        "message.shinobiarts.already_known": "You already know %s.",
        "message.shinobiarts.wrong_clan": "Only the %s clan can learn this jutsu.",
        "message.shinobiarts.need_affinity": "Discover your nature affinity with Chakra Paper first.",
        "message.shinobiarts.need_nature": "You need %s to learn this. Train it with a Training Scroll.",
        "message.shinobiarts.need_chakra": "Your chakra is too weak: needs %s max chakra (you have %s). Keep using jutsu to train.",
        "message.shinobiarts.learned": "You learned %s!",
        "message.shinobiarts.already_have_nature": "You already have %s.",
        "message.shinobiarts.nature_unlocked": "You can now learn %s jutsu!",
        "message.shinobiarts.affinity_known": "Your affinity is %s.",
        "message.shinobiarts.affinity_revealed": "Your nature affinity is %s! You can now learn its jutsu.",
        "message.shinobiarts.paper.fire": "The paper ignites and burns to ash...",
        "message.shinobiarts.paper.water": "The paper turns damp...",
        "message.shinobiarts.paper.wind": "The paper splits cleanly in two...",
        "message.shinobiarts.paper.lightning": "The paper wrinkles and crackles...",
        "message.shinobiarts.paper.earth": "The paper crumbles into dirt...",
        "message.shinobiarts.pill": "+%s chakra",
        "message.shinobiarts.substitution_ready": "Substitution set: the next hit will miss you.",
        "message.shinobiarts.substitution_used": "Substitution!",
        "message.shinobiarts.rasengan_ready": "Rasengan formed: punch something!",
        "message.shinobiarts.dodged": "Sharingan: dodged!",
        "message.shinobiarts.no_dojutsu": "Your clan has no eye technique.",
        "message.shinobiarts.dojutsu_on": "%s activated",
        "message.shinobiarts.dojutsu_off": "%s deactivated",
        "message.shinobiarts.welcome.clan": "You were born into the %s clan.",
        "message.shinobiarts.welcome.dojutsu": "Your bloodline carries the %s. Press V to activate it.",
        "message.shinobiarts.welcome.paper": "Craft Chakra Paper (paper + lapis lazuli) to discover your nature affinity.",
        "message.shinobiarts.welcome.keys": "Press J for your ninja menu, R to cast, G/H to switch jutsu, and hold Z to charge chakra.",

        "death.attack.shinobiarts.jutsu": "%1$s was struck down by a jutsu",
        "death.attack.shinobiarts.jutsu.player": "%1$s was struck down by %2$s's jutsu",
        "death.attack.shinobiarts.jutsu.item": "%1$s was struck down by %2$s's jutsu using %3$s",
        "death.attack.shinobiarts.amaterasu": "%1$s was consumed by black flames",
        "death.attack.shinobiarts.amaterasu.player": "%1$s was consumed by black flames while fighting %2$s",
        "death.attack.shinobiarts.amaterasu.item": "%1$s was consumed by black flames while fighting %2$s",
    }
    for n, name in NATURE_NAMES.items():
        lang["nature.shinobiarts." + n] = name
    for n in NATURES:
        lang["item.shinobiarts.nature_scroll_" + n] = NATURE_NAMES[n] + " Training Scroll"
        item_model("nature_scroll_" + n, "nature_scroll_" + n)

    seen_recipes = {}

    def track(name, key):
        assert key not in seen_recipes, f"recipe {name} has the same ingredients as {seen_recipes[key]}"
        seen_recipes[key] = name

    for j in jutsus:
        jid = j["id"]
        full, desc = JUTSU_TEXT[jid]
        lang["jutsu.shinobiarts." + jid] = full
        lang["jutsu.shinobiarts." + jid + ".desc"] = desc
        lang["item.shinobiarts.scroll_" + jid] = "Jutsu Scroll: " + short_name(full)
        category = "clan" if j["clan"] else ("basic" if j["nature"] == "none" else j["nature"])
        item_model("scroll_" + jid, "scroll_" + category)
        if jid in SPECIAL_RECIPES:
            extra = SPECIAL_RECIPES[jid]
        else:
            extra = [CATALYST[j["nature"]]] * 2 + ([TIER_ITEM[j["tier"]]] if TIER_ITEM[j["tier"]] else [])
        track("scroll_" + jid, shapeless("scroll_" + jid, [MODID + ":blank_scroll"] + extra, MODID + ":scroll_" + jid))

    for n in NATURES:
        track("nature_scroll_" + n, shapeless("nature_scroll_" + n,
                  [MODID + ":blank_scroll"] + [CATALYST[n]] * 3 + ["minecraft:emerald"], MODID + ":nature_scroll_" + n))

    # Basic items
    track("blank_scroll", shapeless("blank_scroll", ["minecraft:paper"] * 3 + ["minecraft:stick"], MODID + ":blank_scroll"))
    track("chakra_paper", shapeless("chakra_paper", ["minecraft:paper", "minecraft:lapis_lazuli"], MODID + ":chakra_paper", 2))
    track("chakra_pill", shapeless("chakra_pill", ["minecraft:sugar", "minecraft:sweet_berries", "minecraft:glowstone_dust"],
                                   MODID + ":chakra_pill", 2))
    track("explosive_tag", shapeless("explosive_tag", ["minecraft:paper", "minecraft:gunpowder", "minecraft:redstone"],
                                     MODID + ":explosive_tag", 2, "equipment"))
    shaped("kunai", [" I", "S "], {"I": "minecraft:iron_ingot", "S": "minecraft:stick"}, MODID + ":kunai", 3)
    shaped("shuriken", [" N ", "NIN", " N "], {"N": "minecraft:iron_nugget", "I": "minecraft:iron_ingot"}, MODID + ":shuriken", 4)

    item_model("kunai", "kunai", "minecraft:item/handheld")
    for name in ("shuriken", "explosive_tag", "chakra_pill", "chakra_paper", "blank_scroll"):
        item_model(name, name)

    # Earth wall block
    write_json(os.path.join(ASSETS, "blockstates", "earth_wall.json"), {"variants": {"": {"model": MODID + ":block/earth_wall"}}})
    write_json(os.path.join(ASSETS, "models", "block", "earth_wall.json"),
               {"parent": "minecraft:block/cube_all", "textures": {"all": MODID + ":block/earth_wall"}})

    # Damage types (for death messages)
    write_json(os.path.join(DATA, "damage_type", "jutsu.json"),
               {"exhaustion": 0.1, "message_id": "shinobiarts.jutsu", "scaling": "when_caused_by_living_non_player"})
    write_json(os.path.join(DATA, "damage_type", "amaterasu.json"),
               {"effects": "burning", "exhaustion": 0.0, "message_id": "shinobiarts.amaterasu", "scaling": "never"})

    write_json(os.path.join(ASSETS, "lang", "en_us.json"), dict(sorted(lang.items())))
    print(f"{len(jutsus)} jutsu, {len(lang)} lang keys, {len(seen_recipes) + 2} recipes")


if __name__ == "__main__":
    main()
