# Shinobi Arts — a ninja mod for Minecraft Forge 1.20.1

Chakra, elemental jutsu learned from scrolls, ninja tools, and clans with eye techniques.

## Build it (one time setup, ~5 minutes)

1. **Install Java 17.** Get the "JDK 17" installer from https://adoptium.net (pick version 17, LTS).
2. **Unzip this project** somewhere, e.g. `Documents/shinobi-arts`.
3. **Open a terminal in that folder**
   - Windows: open the folder in File Explorer, click the address bar, type `cmd`, press Enter.
   - Mac/Linux: right-click the folder → "Open in Terminal".
4. **Build:**
   - Windows: `gradlew build`
   - Mac/Linux: `./gradlew build`

   The first build downloads Minecraft and Forge, so it takes a few minutes. When it says
   `BUILD SUCCESSFUL`, your mod is at **`build/libs/shinobiarts-1.0.0.jar`**.
5. **Install:** put that jar in your `.minecraft/mods` folder and launch Minecraft with
   **Forge 1.20.1 (47.3.0 or newer)**.

Want to test without touching your real game? Run `gradlew runClient` — it opens a dev copy of
Minecraft with the mod loaded.

If the build fails, copy the red error text and send it to me — I'll fix it.

### No Java? Let GitHub build the jar for you

1. Make a free account at https://github.com and click **New repository** (any name, Public or Private).
2. On the empty repo page, click **uploading an existing file**, then drag in **everything inside**
   the unzipped `shinobi-arts` folder (including the `.github` folder) and click **Commit changes**.
   - Mac hides folders starting with a dot: press **Cmd + Shift + .** in Finder to show `.github`.
3. Open the **Actions** tab. A "Build mod jar" run starts by itself and takes about 5 minutes.
4. When it shows a green check, click the run and download **shinobiarts-jar** at the bottom.
   Unzip it to get `shinobiarts-1.0.0.jar`.

If the `.github` folder didn't upload, go to **Actions → set up a workflow yourself**, paste the
contents of `.github/workflows/build.yml`, and commit.

## Controls (rebind in Options → Controls → Shinobi Arts)

| Key | Action |
|---|---|
| **R** | Cast selected jutsu |
| **G / H** | Next / previous jutsu |
| **J** | Ninja menu (your clan, natures, chakra; click a jutsu to select it) |
| **V** | Toggle Sharingan / Byakugan (Uchiha / Hyuga only) |
| **Z** (hold) | Charge chakra (fast regen, but you're slowed) |

The top-left of the screen shows your chakra bar, selected jutsu and its cooldown.

## How progression works

1. **You're born into a clan** the first time you join (random): Uchiha, Hyuga, Uzumaki, Nara, or clanless.
2. **Discover your nature affinity** with **Chakra Paper** (paper + lapis lazuli). Everyone has one
   hidden element: Fire, Water, Wind, Lightning or Earth. Uchiha are always Fire.
3. **Learn jutsu from scrolls.** Craft a jutsu scroll and right-click it. It's learned permanently —
   no inventory space used. You can only learn elements you have.
4. **Unlock more elements** with **Training Scrolls** (one per element).
5. **Train your chakra.** Every jutsu you cast permanently raises your max chakra a little.
   Tier 2 scrolls need 120 max chakra, tier 3 need 160.

### Clans

| Clan | Perks |
|---|---|
| **Uchiha** | Fire affinity. **Sharingan (V):** 25% chance to dodge attacks; instantly *copies* any jutsu another player casts in front of you. Can learn **Amaterasu**. |
| **Hyuga** | **Byakugan (V):** night vision and see every creature within 32 blocks through walls. **Gentle Fist:** while active, punches deal +40% damage, weaken the target and drain enemy players' chakra. Can learn **Palm Rotation**. |
| **Uzumaki** | 150 base chakra (vs 100) and 50% faster regen. Shadow Clone makes 4 clones instead of 2. |
| **Nara** | Can learn **Shadow Possession**. |
| **Clanless** | Trains max chakra 50% faster. |

Eye techniques drain 3 chakra per second while active.

## Jutsu & recipes

All scroll recipes are shapeless: put the items anywhere in a crafting grid.
**Blank Scroll** = 3 paper + 1 stick.

| Jutsu | Element | Tier | Chakra | Recipe (Blank Scroll +) |
|---|---|---|---|---|
| Great Fireball | Fire | 1 | 25 | 2 blaze powder |
| Phoenix Flower | Fire | 2 | 30 | 2 blaze powder, gold ingot |
| Great Fire Annihilation | Fire | 3 | 60 | 2 blaze powder, diamond |
| Water Bullet | Water | 1 | 15 | 2 prismarine shards |
| Water Prison | Water | 2 | 35 | 2 prismarine shards, gold ingot |
| Water Dragon | Water | 3 | 55 | 2 prismarine shards, diamond |
| Gale Palm | Wind | 1 | 15 | 2 feathers |
| Vacuum Blade | Wind | 2 | 25 | 2 feathers, gold ingot |
| Great Breakthrough | Wind | 3 | 45 | 2 feathers, diamond |
| Lightning Armor | Lightning | 1 | 35 | 2 copper ingots |
| Chidori | Lightning | 2 | 40 | 2 copper ingots, gold ingot |
| Thunder Strike | Lightning | 3 | 50 | 2 copper ingots, diamond |
| Earth Wall | Earth | 1 | 25 | 2 clay balls |
| Rock Armor | Earth | 2 | 30 | 2 clay balls, gold ingot |
| Rising Spikes | Earth | 3 | 45 | 2 clay balls, diamond |
| Substitution Jutsu *(everyone starts with this)* | — | 1 | 20 | any log, lapis lazuli |
| Body Flicker | — | 1 | 15 | feather, sugar |
| Shadow Clone Jutsu | — | 2 | 40 | 2 lapis lazuli, gold ingot |
| Rasengan | — | 3 | 45 | 2 lapis lazuli, diamond |
| Shadow Possession *(Nara)* | Clan | 2 | 35 | 2 ink sacs, gold ingot |
| Eight Trigrams Palm Rotation *(Hyuga)* | Clan | 2 | 35 | 2 nether quartz, gold ingot |
| Amaterasu *(Uchiha, Sharingan on)* | Clan | 3 | 80 | ink sac, blaze powder, eye of ender, diamond |

**Training Scroll** (unlock an element): Blank Scroll + 3 of that element's item + emerald.

### Ninja tools

| Item | Recipe | Use |
|---|---|---|
| Kunai ×3 | iron ingot diagonally above a stick (2×2) | Melee weapon (5 dmg) or right-click to throw. Drops where it lands. |
| Shuriken ×4 | iron ingot in the center, iron nuggets above/below/left/right | Fast, rapid throws. |
| Explosive Tag ×2 | paper + gunpowder + redstone | Throw it: sticks to blocks and explodes after 2 s. |
| Chakra Pill ×2 | sugar + sweet berries + glowstone dust | Eat for +50 chakra. |
| Chakra Paper ×2 | paper + lapis lazuli | Reveals your nature affinity. |

## Admin commands (operators)

```
/shinobi info [player]
/shinobi clan <player> <none|uchiha|hyuga|uzumaki|nara>
/shinobi nature <player> <fire|water|wind|lightning|earth>
/shinobi learn <player> <jutsu|all>        (ignores all requirements — good for testing)
/shinobi forget <player> <jutsu|all>
/shinobi training <player> <0-400>          (bonus max chakra)
/shinobi refill <player>                    (full chakra, no cooldowns)
/shinobi reset <player>                     (re-roll clan and affinity)
```

Quick test: `/shinobi learn @s all` then `/shinobi training @s 400`.

## Config

`config/shinobiarts-common.toml` (created on first launch):
- `jutsuGriefing` — fire, plant-breaking and explosive tag block damage (also obeys the `mobGriefing` gamerule)
- `damageMultiplier`, `cooldownMultiplier`, `chakraRegenMultiplier`
- `tierRequirements` — turn off the max-chakra requirement for tier 2/3 scrolls

## Making it yours

- **Rename the mod:** change `mod_name` in `gradle.properties` (keep `mod_id` unless you also rename it in `ShinobiArts.java` and the `assets/`/`data/` folders).
- **Textures** are original placeholders in `src/main/resources/assets/shinobiarts/textures/`. Replace any PNG with your own 16×16 art (same file name).
- **Add a jutsu:** register it in `jutsu/Jutsus.java`, write its effect in `jutsu/JutsuEffects.java`,
  add its name, description and recipe in `tools/make_resources.py`, then run `python3 tools/make_resources.py`.
- **Balance:** chakra costs, cooldowns and tiers are all in the table at the top of `Jutsus.java`.

## Project layout

```
src/main/java/com/shinobiarts/
  ShinobiArts.java, Config.java   mod entry point and config
  ninja/      clans, natures, per-player data (chakra, jutsu, cooldowns)
  jutsu/      jutsu list, effects, casting, per-tick logic
  entity/     jutsu projectiles, thrown kunai/shuriken, explosive tags, shadow clones
  item/       scrolls, chakra paper/pill, throwables
  network/    keybind and sync packets
  client/     keybinds, HUD, ninja menu, shadow clone renderer
  command/    /shinobi
src/main/resources/   textures, models, recipes, lang, damage types
tools/                scripts that generated the textures and JSON files
```
