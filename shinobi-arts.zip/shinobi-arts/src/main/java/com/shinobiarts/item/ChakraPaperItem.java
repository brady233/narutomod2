package com.shinobiarts.item;

import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

import javax.annotation.Nullable;
import java.util.List;

/** Channel chakra into the paper to discover (and unlock) your nature affinity. */
public class ChakraPaperItem extends Item {
    public ChakraPaperItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        NinjaData data = NinjaData.get(sp);
        if (data == null || !data.isInitialized()) return InteractionResultHolder.pass(stack);

        ChakraNature affinity = data.getAffinity();
        if (data.isAffinityRevealed()) {
            sp.displayClientMessage(Component.translatable("message.shinobiarts.affinity_known", affinity.displayName()).withStyle(ChatFormatting.GRAY), true);
            return InteractionResultHolder.fail(stack);
        }

        data.revealAffinity();
        if (!player.getAbilities().instabuild) stack.shrink(1);

        ParticleOptions particle;
        SoundEvent sound;
        switch (affinity) {
            case FIRE -> { particle = ParticleTypes.FLAME; sound = SoundEvents.FIRECHARGE_USE; }
            case WATER -> { particle = ParticleTypes.SPLASH; sound = SoundEvents.PLAYER_SPLASH; }
            case WIND -> { particle = ParticleTypes.SWEEP_ATTACK; sound = SoundEvents.PLAYER_ATTACK_SWEEP; }
            case LIGHTNING -> { particle = ParticleTypes.ELECTRIC_SPARK; sound = SoundEvents.TRIDENT_THUNDER; }
            default -> { particle = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()); sound = SoundEvents.GRAVEL_BREAK; }
        }
        sp.serverLevel().sendParticles(particle, sp.getX(), sp.getY() + 1.3, sp.getZ(), 25, 0.3, 0.3, 0.3, 0.05);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), sound, sp.getSoundSource(), 0.7f, 1.2f);
        sp.sendSystemMessage(Component.translatable("message.shinobiarts.paper." + affinity.id()).withStyle(ChatFormatting.ITALIC));
        sp.sendSystemMessage(Component.translatable("message.shinobiarts.affinity_revealed", affinity.displayName()).withStyle(ChatFormatting.GREEN));
        ModNetwork.sync(sp);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.chakra_paper").withStyle(ChatFormatting.GRAY));
    }
}
