package com.shinobiarts.item;

import com.shinobiarts.client.ClientNinjaData;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.LearnRules;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Right-click to learn the jutsu written on it. The scroll is used up. */
public class JutsuScrollItem extends Item {
    private final Jutsu jutsu;

    public JutsuScrollItem(Jutsu jutsu, Properties properties) {
        super(properties);
        this.jutsu = jutsu;
    }

    public Jutsu getJutsu() {
        return jutsu;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return jutsu.tier() >= 3 || jutsu.clan() != null;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(player instanceof ServerPlayer sp)) return InteractionResultHolder.success(stack);
        NinjaData data = NinjaData.get(sp);
        if (data == null) return InteractionResultHolder.pass(stack);

        Component problem = LearnRules.check(data, jutsu);
        if (problem != null) {
            sp.displayClientMessage(problem, true);
            return InteractionResultHolder.fail(stack);
        }

        data.learn(jutsu.id());
        if (data.learnedJutsu().size() == 1) data.setSelected(0);
        if (!player.getAbilities().instabuild) stack.shrink(1);
        sp.sendSystemMessage(Component.translatable("message.shinobiarts.learned", jutsu.displayName()).withStyle(ChatFormatting.GREEN));
        sp.serverLevel().sendParticles(ParticleTypes.ENCHANT, sp.getX(), sp.getY() + 1.2, sp.getZ(), 40, 0.5, 0.6, 0.5, 0.5);
        level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), SoundEvents.PLAYER_LEVELUP, sp.getSoundSource(), 0.8f, 1.2f);
        ModNetwork.sync(sp);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(jutsu.displayName());
        if (jutsu.clan() != null) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.clan_only", jutsu.clan().displayName()).withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.shinobiarts.nature", jutsu.nature().displayName()).withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("tooltip.shinobiarts.cost", (int) jutsu.cost(),
                String.format("%.1f", jutsu.cooldown() / 20.0f)).withStyle(ChatFormatting.GRAY));
        if (jutsu.requiredMaxChakra() > 0) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.requires_chakra", (int) jutsu.requiredMaxChakra()).withStyle(ChatFormatting.DARK_AQUA));
        }
        if (jutsu.needsDojutsu()) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.needs_dojutsu").withStyle(ChatFormatting.DARK_RED));
        }
        tooltip.add(jutsu.description().withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        if (level != null && level.isClientSide && ClientNinjaData.get().knows(jutsu.id())) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.known").withStyle(ChatFormatting.GREEN));
        } else {
            tooltip.add(Component.translatable("tooltip.shinobiarts.right_click_learn").withStyle(ChatFormatting.YELLOW));
        }
    }
}
