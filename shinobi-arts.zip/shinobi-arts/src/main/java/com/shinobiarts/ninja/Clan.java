package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.RandomSource;

import javax.annotation.Nullable;

/**
 * Clans a player can be born into. The weight is the relative chance of being born into it.
 * <ul>
 *   <li>NONE - no bloodline, but trains chakra 50% faster.</li>
 *   <li>UCHIHA - always has a Fire affinity; Sharingan (dodge + copy jutsu); can learn Amaterasu.</li>
 *   <li>HYUGA - Byakugan (see through walls + Gentle Fist); can learn Palm Rotation.</li>
 *   <li>UZUMAKI - huge chakra reserves and regen; more shadow clones.</li>
 *   <li>NARA - can learn Shadow Possession.</li>
 * </ul>
 */
public enum Clan {
    NONE("none", 40, ChatFormatting.GRAY),
    UCHIHA("uchiha", 15, ChatFormatting.DARK_RED),
    HYUGA("hyuga", 15, ChatFormatting.WHITE),
    UZUMAKI("uzumaki", 15, ChatFormatting.RED),
    NARA("nara", 15, ChatFormatting.DARK_GREEN);

    private final String id;
    private final int weight;
    private final ChatFormatting color;

    Clan(String id, int weight, ChatFormatting color) {
        this.id = id;
        this.weight = weight;
        this.color = color;
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    public boolean hasDojutsu() {
        return this == UCHIHA || this == HYUGA;
    }

    public MutableComponent displayName() {
        return Component.translatable("clan.shinobiarts." + id).withStyle(color);
    }

    /** Name of this clan's eye technique (only meaningful when {@link #hasDojutsu()}). */
    public MutableComponent dojutsuName() {
        return Component.translatable("dojutsu.shinobiarts." + id).withStyle(this == UCHIHA ? ChatFormatting.RED : ChatFormatting.AQUA);
    }

    public static Clan random(RandomSource random) {
        int total = 0;
        for (Clan c : values()) total += c.weight;
        int roll = random.nextInt(total);
        for (Clan c : values()) {
            roll -= c.weight;
            if (roll < 0) return c;
        }
        return NONE;
    }

    @Nullable
    public static Clan byId(String id) {
        for (Clan c : values()) {
            if (c.id.equals(id)) return c;
        }
        return null;
    }
}
