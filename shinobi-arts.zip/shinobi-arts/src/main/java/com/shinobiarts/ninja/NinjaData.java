package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Everything the mod knows about one player: clan, natures, chakra, learned jutsu and cooldowns.
 * Attached to every player as a capability on the server; a copy lives on the client for the HUD.
 */
public class NinjaData {
    public static final Capability<NinjaData> CAP = CapabilityManager.get(new CapabilityToken<>() {});

    public static final float BASE_MAX_CHAKRA = 100f;
    public static final float UZUMAKI_MAX_CHAKRA = 150f;
    public static final float TRAINING_CAP = 400f;
    /** Each point of chakra spent raises max chakra by this much. */
    public static final float TRAINING_RATE = 0.05f;
    public static final String STARTING_JUTSU = "substitution";

    private boolean initialized;
    private Clan clan = Clan.NONE;
    private ChakraNature affinity = ChakraNature.FIRE;
    private boolean affinityRevealed;
    private final Set<ChakraNature> natures = EnumSet.noneOf(ChakraNature.class);
    private final List<String> learned = new ArrayList<>();
    private int selected;
    private float chakra = BASE_MAX_CHAKRA;
    private float trained;
    private final Map<String, Long> cooldowns = new HashMap<>();

    // Short-lived states (game-time stamps), also synced so the HUD can show them.
    private boolean dojutsuActive;
    private boolean charging;
    private long rasenganUntil;
    private long substitutionUntil;
    private long rotationUntil;

    @Nullable
    public static NinjaData get(Player player) {
        return player.getCapability(CAP).orElse(null);
    }

    /** First-join setup: roll a clan and a hidden nature affinity, teach the academy jutsu. */
    public void init(RandomSource random) {
        clan = Clan.random(random);
        affinity = clan == Clan.UCHIHA ? ChakraNature.FIRE : ChakraNature.ELEMENTS[random.nextInt(ChakraNature.ELEMENTS.length)];
        affinityRevealed = false;
        natures.clear();
        learned.clear();
        cooldowns.clear();
        learned.add(STARTING_JUTSU);
        selected = 0;
        trained = 0;
        chakra = maxChakra();
        dojutsuActive = false;
        charging = false;
        rasenganUntil = substitutionUntil = rotationUntil = 0;
        initialized = true;
    }

    // ---------------------------------------------------------------- chakra

    public float maxChakra() {
        return (clan == Clan.UZUMAKI ? UZUMAKI_MAX_CHAKRA : BASE_MAX_CHAKRA) + trained;
    }

    public float regenPerSecond() {
        float base = clan == Clan.UZUMAKI ? 3.0f : 2.0f;
        return base * Config.CHAKRA_REGEN_MULTIPLIER.get().floatValue();
    }

    public float getChakra() {
        return chakra;
    }

    public void setChakra(float value) {
        chakra = Mth.clamp(value, 0f, maxChakra());
    }

    public void addChakra(float amount) {
        setChakra(chakra + amount);
    }

    public void consumeChakra(float amount) {
        setChakra(chakra - amount);
    }

    /** Spending chakra slowly grows your reserves. Clanless ninja train 50% faster. */
    public void train(float chakraSpent) {
        float rate = TRAINING_RATE * (clan == Clan.NONE ? 1.5f : 1.0f);
        trained = Math.min(TRAINING_CAP, trained + chakraSpent * rate);
    }

    public float getTrained() {
        return trained;
    }

    public void setTrained(float value) {
        trained = Mth.clamp(value, 0f, TRAINING_CAP);
    }

    // ---------------------------------------------------------------- identity

    public boolean isInitialized() {
        return initialized;
    }

    public Clan getClan() {
        return clan;
    }

    public void setClan(Clan clan) {
        this.clan = clan;
        if (!clan.hasDojutsu()) dojutsuActive = false;
        setChakra(chakra);
    }

    public ChakraNature getAffinity() {
        return affinity;
    }

    public void setAffinity(ChakraNature affinity) {
        this.affinity = affinity;
    }

    public boolean isAffinityRevealed() {
        return affinityRevealed;
    }

    /** Chakra Paper: reveal the affinity and unlock that nature. */
    public void revealAffinity() {
        affinityRevealed = true;
        natures.add(affinity);
    }

    public boolean hasNature(ChakraNature nature) {
        return nature == ChakraNature.NONE || natures.contains(nature);
    }

    public void unlockNature(ChakraNature nature) {
        if (nature.isElement()) natures.add(nature);
    }

    public Set<ChakraNature> getNatures() {
        return natures;
    }

    // ---------------------------------------------------------------- jutsu

    public boolean knows(String jutsuId) {
        return learned.contains(jutsuId);
    }

    public void learn(String jutsuId) {
        if (!learned.contains(jutsuId)) learned.add(jutsuId);
    }

    public void forget(String jutsuId) {
        learned.remove(jutsuId);
        selected = learned.isEmpty() ? 0 : Mth.clamp(selected, 0, learned.size() - 1);
    }

    /** Learned jutsu in the order they were learned (unknown ids are skipped). */
    public List<Jutsu> learnedJutsu() {
        List<Jutsu> out = new ArrayList<>();
        for (String id : learned) {
            Jutsu j = Jutsus.get(id);
            if (j != null) out.add(j);
        }
        return out;
    }

    public int getSelected() {
        return selected;
    }

    public void setSelected(int index) {
        List<Jutsu> list = learnedJutsu();
        selected = list.isEmpty() ? 0 : Mth.clamp(index, 0, list.size() - 1);
    }

    public void cycle(int direction) {
        int size = learnedJutsu().size();
        if (size == 0) return;
        selected = Math.floorMod(selected + direction, size);
    }

    @Nullable
    public Jutsu selectedJutsu() {
        List<Jutsu> list = learnedJutsu();
        if (list.isEmpty()) return null;
        return list.get(Mth.clamp(selected, 0, list.size() - 1));
    }

    public long cooldownRemaining(String jutsuId, long now) {
        Long ready = cooldowns.get(jutsuId);
        return ready == null ? 0 : Math.max(0, ready - now);
    }

    public void setCooldown(String jutsuId, long readyAt) {
        cooldowns.put(jutsuId, readyAt);
    }

    // ---------------------------------------------------------------- short-lived states

    public boolean isDojutsuActive() {
        return dojutsuActive;
    }

    public void setDojutsuActive(boolean active) {
        dojutsuActive = active;
    }

    public boolean isCharging() {
        return charging;
    }

    public void setCharging(boolean charging) {
        this.charging = charging;
    }

    public long getRasenganUntil() {
        return rasenganUntil;
    }

    public void setRasenganUntil(long t) {
        rasenganUntil = t;
    }

    public long getSubstitutionUntil() {
        return substitutionUntil;
    }

    public void setSubstitutionUntil(long t) {
        substitutionUntil = t;
    }

    public long getRotationUntil() {
        return rotationUntil;
    }

    public void setRotationUntil(long t) {
        rotationUntil = t;
    }

    /** Clears toggles and buffs, e.g. on death. */
    public void resetStates() {
        dojutsuActive = false;
        charging = false;
        rasenganUntil = substitutionUntil = rotationUntil = 0;
    }

    // ---------------------------------------------------------------- NBT

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("Initialized", initialized);
        tag.putString("Clan", clan.id());
        tag.putString("Affinity", affinity.id());
        tag.putBoolean("AffinityRevealed", affinityRevealed);
        ListTag natureList = new ListTag();
        for (ChakraNature n : natures) natureList.add(StringTag.valueOf(n.id()));
        tag.put("Natures", natureList);
        ListTag learnedList = new ListTag();
        for (String id : learned) learnedList.add(StringTag.valueOf(id));
        tag.put("Learned", learnedList);
        tag.putInt("Selected", selected);
        tag.putFloat("Chakra", chakra);
        tag.putFloat("Trained", trained);
        CompoundTag cds = new CompoundTag();
        cooldowns.forEach(cds::putLong);
        tag.put("Cooldowns", cds);
        tag.putBoolean("Dojutsu", dojutsuActive);
        tag.putBoolean("Charging", charging);
        tag.putLong("Rasengan", rasenganUntil);
        tag.putLong("Substitution", substitutionUntil);
        tag.putLong("Rotation", rotationUntil);
        return tag;
    }

    public void load(CompoundTag tag) {
        initialized = tag.getBoolean("Initialized");
        Clan c = Clan.byId(tag.getString("Clan"));
        clan = c == null ? Clan.NONE : c;
        ChakraNature a = ChakraNature.byId(tag.getString("Affinity"));
        affinity = a == null || !a.isElement() ? ChakraNature.FIRE : a;
        affinityRevealed = tag.getBoolean("AffinityRevealed");
        natures.clear();
        for (Tag t : tag.getList("Natures", Tag.TAG_STRING)) {
            ChakraNature n = ChakraNature.byId(t.getAsString());
            if (n != null && n.isElement()) natures.add(n);
        }
        learned.clear();
        for (Tag t : tag.getList("Learned", Tag.TAG_STRING)) {
            String id = t.getAsString();
            if (!learned.contains(id)) learned.add(id);
        }
        selected = tag.getInt("Selected");
        trained = Mth.clamp(tag.getFloat("Trained"), 0f, TRAINING_CAP);
        chakra = Mth.clamp(tag.getFloat("Chakra"), 0f, maxChakra());
        cooldowns.clear();
        CompoundTag cds = tag.getCompound("Cooldowns");
        for (String key : cds.getAllKeys()) cooldowns.put(key, cds.getLong(key));
        dojutsuActive = tag.getBoolean("Dojutsu");
        charging = tag.getBoolean("Charging");
        rasenganUntil = tag.getLong("Rasengan");
        substitutionUntil = tag.getLong("Substitution");
        rotationUntil = tag.getLong("Rotation");
    }
}
