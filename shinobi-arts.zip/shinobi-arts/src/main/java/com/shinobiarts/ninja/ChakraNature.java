package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import javax.annotation.Nullable;

/** The five chakra natures ("releases"), plus NONE for non-elemental jutsu. */
public enum ChakraNature {
    FIRE("fire", ChatFormatting.RED),
    WATER("water", ChatFormatting.BLUE),
    WIND("wind", ChatFormatting.GREEN),
    LIGHTNING("lightning", ChatFormatting.YELLOW),
    EARTH("earth", ChatFormatting.GOLD),
    NONE("none", ChatFormatting.LIGHT_PURPLE);

    public static final ChakraNature[] ELEMENTS = {FIRE, WATER, WIND, LIGHTNING, EARTH};

    private final String id;
    private final ChatFormatting color;

    ChakraNature(String id, ChatFormatting color) {
        this.id = id;
        this.color = color;
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    public boolean isElement() {
        return this != NONE;
    }

    public MutableComponent displayName() {
        return Component.translatable("nature.shinobiarts." + id).withStyle(color);
    }

    @Nullable
    public static ChakraNature byId(String id) {
        for (ChakraNature n : values()) {
            if (n.id.equals(id)) return n;
        }
        return null;
    }
}
