package com.shinobiarts;

import net.minecraftforge.common.ForgeConfigSpec;

/** Server-wide tuning knobs. Saved to config/shinobiarts-common.toml. */
public final class Config {
    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.BooleanValue JUTSU_GRIEFING = BUILDER
            .comment("Allow jutsu and explosive tags to place fire, break plants/blocks and raise earth walls over grass.",
                     "The mobGriefing gamerule must also be true.")
            .define("jutsuGriefing", true);

    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULTIPLIER = BUILDER
            .comment("Multiplier applied to all jutsu damage.")
            .defineInRange("damageMultiplier", 1.0, 0.0, 10.0);

    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER = BUILDER
            .comment("Multiplier applied to all jutsu cooldowns.")
            .defineInRange("cooldownMultiplier", 1.0, 0.0, 10.0);

    public static final ForgeConfigSpec.DoubleValue CHAKRA_REGEN_MULTIPLIER = BUILDER
            .comment("Multiplier applied to natural chakra regeneration and charging.")
            .defineInRange("chakraRegenMultiplier", 1.0, 0.0, 10.0);

    public static final ForgeConfigSpec.BooleanValue TIER_REQUIREMENTS = BUILDER
            .comment("If true, tier 2 and tier 3 jutsu scrolls require a minimum max chakra to learn.")
            .define("tierRequirements", true);

    public static final ForgeConfigSpec SPEC = BUILDER.build();

    private Config() {}
}
