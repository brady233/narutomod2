package com.shinobiarts.client;

import com.shinobiarts.ninja.NinjaData;
import net.minecraft.nbt.CompoundTag;

/**
 * The local player's ninja data as last sent by the server. Holds no client-only classes,
 * so common code (like item tooltips) can safely read it.
 */
public final class ClientNinjaData {
    private static NinjaData data = new NinjaData();

    private ClientNinjaData() {}

    public static NinjaData get() {
        return data;
    }

    public static void apply(CompoundTag tag) {
        data.load(tag);
    }

    public static void reset() {
        data = new NinjaData();
    }
}
