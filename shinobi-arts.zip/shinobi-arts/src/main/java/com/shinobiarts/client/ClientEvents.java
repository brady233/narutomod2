package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientEvents {
    private static boolean charging;

    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) {
            charging = false;
            return;
        }

        while (KeyBinds.CAST.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.CAST));
        while (KeyBinds.NEXT.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.NEXT));
        while (KeyBinds.PREV.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.PREV));
        while (KeyBinds.DOJUTSU.consumeClick()) ModNetwork.toServer(new ActionPacket(ActionPacket.DOJUTSU));
        while (KeyBinds.MENU.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new NinjaScreen());
        }

        // Charging is held: tell the server when it starts and stops.
        boolean wantCharge = KeyBinds.CHARGE.isDown() && mc.screen == null;
        if (wantCharge != charging) {
            charging = wantCharge;
            ModNetwork.toServer(new ActionPacket(wantCharge ? ActionPacket.CHARGE_START : ActionPacket.CHARGE_STOP));
        }
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        charging = false;
        ClientNinjaData.reset();
    }
}
