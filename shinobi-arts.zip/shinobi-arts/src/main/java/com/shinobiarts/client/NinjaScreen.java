package com.shinobiarts.client;

import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.List;

/** Ninja menu (J): your clan, natures and chakra, plus a button per learned jutsu to select it. */
public class NinjaScreen extends Screen {
    private static final int BUTTON_W = 128;
    private static final int BUTTON_H = 18;
    private static final int GAP = 4;
    private static final int TOP = 74;

    public NinjaScreen() {
        super(Component.translatable("screen.shinobiarts.title"));
    }

    @Override
    protected void init() {
        NinjaData d = ClientNinjaData.get();
        List<Jutsu> list = d.learnedJutsu();
        int cols = Math.max(1, Math.min(4, (this.width - 20 + GAP) / (BUTTON_W + GAP)));
        int totalW = cols * BUTTON_W + (cols - 1) * GAP;
        int left = (this.width - totalW) / 2;

        for (int i = 0; i < list.size(); i++) {
            Jutsu jutsu = list.get(i);
            final int index = i;
            int x = left + (i % cols) * (BUTTON_W + GAP);
            int y = TOP + (i / cols) * (BUTTON_H + GAP);
            MutableComponent label = jutsu.displayName();
            if (i == d.getSelected()) label = Component.literal("> ").append(label).append(" <");
            Button button = Button.builder(label, b -> {
                        ModNetwork.toServer(new ActionPacket(ActionPacket.SELECT, index));
                        d.setSelected(index);
                        this.onClose();
                    })
                    .bounds(x, y, BUTTON_W, BUTTON_H)
                    .tooltip(Tooltip.create(tooltipFor(jutsu)))
                    .build();
            this.addRenderableWidget(button);
        }

        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose())
                .bounds(this.width / 2 - 50, this.height - 26, 100, 20)
                .build());
    }

    private static Component tooltipFor(Jutsu jutsu) {
        MutableComponent tip = jutsu.displayName().copy();
        tip.append("\n").append(Component.translatable("tooltip.shinobiarts.cost", (int) jutsu.cost(),
                String.format("%.1f", jutsu.cooldown() / 20.0f)).withStyle(ChatFormatting.GRAY));
        tip.append("\n").append(jutsu.description().withStyle(ChatFormatting.DARK_GRAY));
        return tip;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        NinjaData d = ClientNinjaData.get();
        int cx = this.width / 2;
        g.drawCenteredString(this.font, this.title, cx, 10, 0xFFFFFF);

        MutableComponent natures = Component.empty();
        boolean first = true;
        for (ChakraNature n : ChakraNature.ELEMENTS) {
            if (!d.hasNature(n)) continue;
            if (!first) natures.append(", ");
            natures.append(n.displayName());
            first = false;
        }
        if (first) natures.append(Component.literal("-").withStyle(ChatFormatting.GRAY));

        Component affinity = d.isAffinityRevealed()
                ? d.getAffinity().displayName()
                : Component.translatable("screen.shinobiarts.affinity_unknown").withStyle(ChatFormatting.GRAY);

        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.clan", d.getClan().displayName()), cx, 26, 0xDDDDDD);
        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.affinity", affinity), cx, 37, 0xDDDDDD);
        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.natures", natures), cx, 48, 0xDDDDDD);
        g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.chakra", (int) d.getChakra(), (int) d.maxChakra()), cx, 59, 0x9FD8FF);

        if (d.learnedJutsu().isEmpty()) {
            g.drawCenteredString(this.font, Component.translatable("screen.shinobiarts.no_jutsu").withStyle(ChatFormatting.GRAY), cx, TOP + 4, 0xFFFFFF);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
