package com.shinobiarts.client;

import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Top-left HUD: chakra bar, selected jutsu with cooldown, and active techniques. */
public final class ChakraHud {
    private static final int X = 6;
    private static final int Y = 6;
    private static final int BAR_WIDTH = 102;
    private static final int BAR_HEIGHT = 7;

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height);

    private ChakraHud() {}

    private static void render(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.level == null || mc.player.isSpectator()) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.isInitialized()) return;
        Font font = mc.font;
        long now = mc.level.getGameTime();

        // Eye technique tint around the screen edges.
        if (d.isDojutsuActive()) {
            int tint = d.getClan() == Clan.UCHIHA ? 0x50A00000 : 0x40C8DCFF;
            int band = Math.max(20, height / 7);
            g.fillGradient(0, 0, width, band, tint, 0x00000000);
            g.fillGradient(0, height - band, width, height, 0x00000000, tint);
        }

        float max = d.maxChakra();
        float cur = d.getChakra();
        g.drawString(font, Component.translatable("hud.shinobiarts.chakra", (int) cur, (int) max), X, Y, 0x9FD8FF, true);

        int barY = Y + 11;
        g.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + BAR_HEIGHT + 1, 0xC0101020);
        int filled = (int) (BAR_WIDTH * Mth.clamp(cur / max, 0f, 1f));
        int color = d.isCharging() ? 0xFF8FE8FF : 0xFF2F8CFF;
        g.fill(X, barY, X + filled, barY + BAR_HEIGHT, color);
        g.fill(X, barY, X + filled, barY + 2, 0x55FFFFFF);
        if (d.isCharging()) {
            // Little moving shimmer while charging.
            int shimmer = (int) ((now * 4) % (BAR_WIDTH + 12)) - 6;
            int s0 = Mth.clamp(shimmer, 0, filled);
            int s1 = Mth.clamp(shimmer + 6, 0, filled);
            if (s1 > s0) g.fill(X + s0, barY, X + s1, barY + BAR_HEIGHT, 0x88FFFFFF);
        }

        int textY = barY + BAR_HEIGHT + 4;
        Jutsu jutsu = d.selectedJutsu();
        String castKey = KeyBinds.CAST.getTranslatedKeyMessage().getString();
        if (jutsu != null) {
            long remaining = d.cooldownRemaining(jutsu.id(), now);
            MutableComponent status = remaining > 0
                    ? Component.literal(String.format(" %.1fs", remaining / 20.0f)).withStyle(ChatFormatting.GRAY)
                    : (cur >= jutsu.cost()
                        ? Component.translatable("hud.shinobiarts.ready").withStyle(ChatFormatting.GREEN)
                        : Component.translatable("hud.shinobiarts.low_chakra").withStyle(ChatFormatting.RED));
            MutableComponent line = Component.literal("[" + castKey + "] ").withStyle(ChatFormatting.DARK_GRAY)
                    .append(jutsu.displayName())
                    .append(Component.literal(" (" + (int) jutsu.cost() + ")").withStyle(ChatFormatting.AQUA))
                    .append(status);
            g.drawString(font, line, X, textY, 0xFFFFFF, true);
        } else {
            g.drawString(font, Component.translatable("hud.shinobiarts.no_jutsu",
                    KeyBinds.MENU.getTranslatedKeyMessage().getString()).withStyle(ChatFormatting.GRAY), X, textY, 0xFFFFFF, true);
        }

        // Active techniques.
        int statusY = textY + 11;
        if (d.isDojutsuActive()) {
            g.drawString(font, d.getClan().dojutsuName(), X, statusY, 0xFFFFFF, true);
            statusY += 10;
        }
        if (d.isCharging()) {
            g.drawString(font, Component.translatable("hud.shinobiarts.charging").withStyle(ChatFormatting.AQUA), X, statusY, 0xFFFFFF, true);
            statusY += 10;
        }
        if (d.getRasenganUntil() > now) {
            g.drawString(font, Component.translatable("hud.shinobiarts.rasengan").withStyle(ChatFormatting.AQUA), X, statusY, 0xFFFFFF, true);
            statusY += 10;
        }
        if (d.getSubstitutionUntil() > now) {
            g.drawString(font, Component.translatable("hud.shinobiarts.substitution").withStyle(ChatFormatting.LIGHT_PURPLE), X, statusY, 0xFFFFFF, true);
        }
    }
}
