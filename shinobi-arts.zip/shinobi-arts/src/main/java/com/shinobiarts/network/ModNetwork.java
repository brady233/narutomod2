package com.shinobiarts.network;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            ShinobiArts.id("main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(ActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ActionPacket::encode)
                .decoder(ActionPacket::new)
                .consumerMainThread(ActionPacket::handle)
                .add();
        CHANNEL.messageBuilder(SyncPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncPacket::encode)
                .decoder(SyncPacket::new)
                .consumerMainThread(SyncPacket::handle)
                .add();
    }

    /** Sends the player's full ninja data to their own client (for the HUD and menu). */
    public static void sync(ServerPlayer player) {
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new SyncPacket(data.save()));
    }

    public static void toServer(Object message) {
        CHANNEL.sendToServer(message);
    }

    private ModNetwork() {}
}
