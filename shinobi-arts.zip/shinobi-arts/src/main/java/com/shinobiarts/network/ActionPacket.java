package com.shinobiarts.network;

import com.shinobiarts.jutsu.ServerActions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: a keybind was pressed. */
public class ActionPacket {
    public static final int CAST = 0;
    public static final int NEXT = 1;
    public static final int PREV = 2;
    public static final int SELECT = 3;
    public static final int DOJUTSU = 4;
    public static final int CHARGE_START = 5;
    public static final int CHARGE_STOP = 6;

    private final int action;
    private final int arg;

    public ActionPacket(int action) {
        this(action, 0);
    }

    public ActionPacket(int action, int arg) {
        this.action = action;
        this.arg = arg;
    }

    public ActionPacket(FriendlyByteBuf buf) {
        this.action = buf.readVarInt();
        this.arg = buf.readVarInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(action);
        buf.writeVarInt(arg);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer player = ctx.get().getSender();
        if (player != null) ServerActions.handle(player, action, arg);
    }
}
