package com.shinobiarts.event;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.command.ShinobiCommand;
import com.shinobiarts.jutsu.JutsuEffects;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.jutsu.NinjaTicker;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.NinjaDataProvider;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ShinobiArts.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonEvents {
    private static final ResourceLocation NINJA_DATA_ID = ShinobiArts.id("ninja_data");
    private static final float SHARINGAN_DODGE_CHANCE = 0.25f;

    private CommonEvents() {}

    // ---------------------------------------------------------------- player data lifecycle

    @SubscribeEvent
    public static void attachCapabilities(AttachCapabilitiesEvent<Entity> event) {
        if (event.getObject() instanceof Player) {
            NinjaDataProvider provider = new NinjaDataProvider();
            event.addCapability(NINJA_DATA_ID, provider);
            event.addListener(provider::invalidate);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        Player original = event.getOriginal();
        original.reviveCaps();
        NinjaData oldData = NinjaData.get(original);
        NinjaData newData = NinjaData.get(event.getEntity());
        if (oldData != null && newData != null) {
            newData.load(oldData.save());
            if (event.isWasDeath()) {
                newData.resetStates();
                newData.setChakra(newData.maxChakra());
            }
        }
        original.invalidateCaps();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        if (!data.isInitialized()) {
            data.init(player.getRandom());
            welcome(player, data);
        }
        data.setCharging(false);
        ModNetwork.sync(player);
    }

    private static void welcome(ServerPlayer player, NinjaData data) {
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.clan", data.getClan().displayName()).withStyle(ChatFormatting.GOLD));
        if (data.getClan().hasDojutsu()) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.dojutsu", data.getClan().dojutsuName()).withStyle(ChatFormatting.GOLD));
        }
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.paper").withStyle(ChatFormatting.YELLOW));
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.keys").withStyle(ChatFormatting.YELLOW));
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ModNetwork.sync(player);
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) ModNetwork.sync(player);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.END && event.side == LogicalSide.SERVER && event.player instanceof ServerPlayer player) {
            NinjaTicker.tick(player);
        }
    }

    @SubscribeEvent
    public static void registerCommands(RegisterCommandsEvent event) {
        ShinobiCommand.register(event.getDispatcher());
    }

    // ---------------------------------------------------------------- combat

    /** Defensive techniques: Palm Rotation, Substitution and the Sharingan's dodge. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.getEntity() == null || source.getEntity() == player) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        long now = player.level().getGameTime();

        if (data.getRotationUntil() > now) {
            event.setCanceled(true);
            return;
        }
        if (data.getSubstitutionUntil() > now) {
            event.setCanceled(true);
            data.setSubstitutionUntil(0);
            JutsuEffects.triggerSubstitution(player, source.getEntity());
            ModNetwork.sync(player);
            return;
        }
        if (data.getClan() == Clan.UCHIHA && data.isDojutsuActive() && player.getRandom().nextFloat() < SHARINGAN_DODGE_CHANCE) {
            event.setCanceled(true);
            player.serverLevel().sendParticles(ParticleTypes.CRIT, player.getX(), player.getY() + 1, player.getZ(), 10, 0.3, 0.5, 0.3, 0.1);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.PLAYER_ATTACK_NODAMAGE, 1.0f, 1.4f);
            player.displayClientMessage(Component.translatable("message.shinobiarts.dodged").withStyle(ChatFormatting.RED), true);
        }
    }

    /** Offensive melee buffs: a charged Rasengan and the Hyuga's Gentle Fist. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        DamageSource source = event.getSource();
        if (!source.is(DamageTypes.PLAYER_ATTACK) || !(source.getEntity() instanceof ServerPlayer player) || source.getDirectEntity() != player) return;
        NinjaData data = NinjaData.get(player);
        if (data == null) return;
        LivingEntity target = event.getEntity();
        long now = player.level().getGameTime();
        boolean changed = false;

        if (data.getRasenganUntil() > now) {
            event.setAmount(event.getAmount() + JutsuUtil.dmg(14f));
            data.setRasenganUntil(0);
            JutsuEffects.rasenganHit(player, target);
            changed = true;
        }

        if (data.getClan() == Clan.HYUGA && data.isDojutsuActive()) {
            // Gentle Fist: strikes the chakra points directly.
            event.setAmount(event.getAmount() * 1.4f);
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            Vec3 c = target.getBoundingBox().getCenter();
            player.serverLevel().sendParticles(ParticleTypes.ENCHANTED_HIT, c.x, c.y, c.z, 12, 0.3, 0.3, 0.3, 0.2);
            if (target instanceof ServerPlayer victim) {
                NinjaData victimData = NinjaData.get(victim);
                if (victimData != null) {
                    victimData.consumeChakra(15f);
                    ModNetwork.sync(victim);
                }
            }
        }

        if (changed) ModNetwork.sync(player);
    }
}
