package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.ChakraPaperItem;
import com.shinobiarts.item.ChakraPillItem;
import com.shinobiarts.item.ExplosiveTagItem;
import com.shinobiarts.item.JutsuScrollItem;
import com.shinobiarts.item.NatureScrollItem;
import com.shinobiarts.item.ThrownToolItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.ninja.ChakraNature;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ShinobiArts.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ShinobiArts.MODID);

    // ---------------------------------------------------------------- ninja tools
    /** Stackable throwing knife that is also a decent melee weapon (5 damage). */
    public static final RegistryObject<Item> KUNAI = ITEMS.register("kunai",
            () -> new ThrownToolItem(new Item.Properties().stacksTo(16), 2.0f, 12, 4.0, -2.0));
    public static final RegistryObject<Item> SHURIKEN = ITEMS.register("shuriken",
            () -> new ThrownToolItem(new Item.Properties().stacksTo(32), 2.6f, 6, 0.0, 0.0));
    public static final RegistryObject<Item> EXPLOSIVE_TAG = ITEMS.register("explosive_tag",
            () -> new ExplosiveTagItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> CHAKRA_PILL = ITEMS.register("chakra_pill",
            () -> new ChakraPillItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.2f).alwaysEat().fast().build())));
    public static final RegistryObject<Item> CHAKRA_PAPER = ITEMS.register("chakra_paper",
            () -> new ChakraPaperItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BLANK_SCROLL = ITEMS.register("blank_scroll",
            () -> new Item(new Item.Properties()));

    // ---------------------------------------------------------------- scrolls (one per jutsu / nature)
    public static final Map<String, RegistryObject<Item>> JUTSU_SCROLLS = new LinkedHashMap<>();
    public static final Map<ChakraNature, RegistryObject<Item>> NATURE_SCROLLS = new EnumMap<>(ChakraNature.class);

    static {
        for (ChakraNature nature : ChakraNature.ELEMENTS) {
            NATURE_SCROLLS.put(nature, ITEMS.register("nature_scroll_" + nature.id(),
                    () -> new NatureScrollItem(nature, new Item.Properties().stacksTo(16).rarity(Rarity.RARE))));
        }
        for (Jutsu jutsu : Jutsus.all()) {
            JUTSU_SCROLLS.put(jutsu.id(), ITEMS.register("scroll_" + jutsu.id(),
                    () -> new JutsuScrollItem(jutsu, new Item.Properties().stacksTo(16).rarity(rarityFor(jutsu)))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts"))
            .icon(() -> new ItemStack(KUNAI.get()))
            .displayItems((params, output) -> ITEMS.getEntries().forEach(entry -> output.accept(entry.get())))
            .build());

    private static Rarity rarityFor(Jutsu jutsu) {
        if (jutsu.clan() != null) return Rarity.EPIC;
        return switch (jutsu.tier()) {
            case 1 -> Rarity.COMMON;
            case 2 -> Rarity.UNCOMMON;
            default -> Rarity.RARE;
        };
    }

    private ModItems() {}
}
