package com.shinobiarts.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /shinobi info [player]                     - show clan, natures, chakra and jutsu
 * /shinobi clan <player> <clan>              - change clan (op)
 * /shinobi nature <player> <nature>          - reveal affinity + unlock a nature (op)
 * /shinobi learn <player> <jutsu|all>        - teach a jutsu, ignoring requirements (op)
 * /shinobi forget <player> <jutsu|all>       - forget a jutsu (op)
 * /shinobi training <player> <amount>        - set bonus max chakra, 0-400 (op)
 * /shinobi refill <player>                   - refill chakra and clear cooldowns (op)
 * /shinobi reset <player>                    - re-roll as a brand new ninja (op)
 */
public final class ShinobiCommand {
    private static final SuggestionProvider<CommandSourceStack> CLANS = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(Clan.values()).map(Clan::id), builder);
    private static final SuggestionProvider<CommandSourceStack> NATURES = (ctx, builder) ->
            SharedSuggestionProvider.suggest(Arrays.stream(ChakraNature.ELEMENTS).map(ChakraNature::id), builder);
    private static final SuggestionProvider<CommandSourceStack> JUTSU = (ctx, builder) -> {
        List<String> ids = new ArrayList<>();
        ids.add("all");
        for (Jutsu j : Jutsus.all()) ids.add(j.id());
        return SharedSuggestionProvider.suggest(ids, builder);
    };

    private ShinobiCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shinobi")
                .then(Commands.literal("info")
                        .executes(ctx -> info(ctx, ctx.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(s -> s.hasPermission(2))
                                .executes(ctx -> info(ctx, EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("clan").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("clan", StringArgumentType.word()).suggests(CLANS)
                                        .executes(ShinobiCommand::setClan))))
                .then(Commands.literal("nature").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("nature", StringArgumentType.word()).suggests(NATURES)
                                        .executes(ShinobiCommand::unlockNature))))
                .then(Commands.literal("learn").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("jutsu", StringArgumentType.word()).suggests(JUTSU)
                                        .executes(ctx -> learn(ctx, true)))))
                .then(Commands.literal("forget").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("jutsu", StringArgumentType.word()).suggests(JUTSU)
                                        .executes(ctx -> learn(ctx, false)))))
                .then(Commands.literal("training").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", FloatArgumentType.floatArg(0, NinjaData.TRAINING_CAP))
                                        .executes(ShinobiCommand::training))))
                .then(Commands.literal("refill").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ShinobiCommand::refill)))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ShinobiCommand::reset))));
    }

    private static NinjaData data(ServerPlayer player) throws CommandSyntaxException {
        NinjaData data = NinjaData.get(player);
        if (data == null) throw EntityArgument.NO_PLAYERS_FOUND.create();
        return data;
    }

    private static int info(CommandContext<CommandSourceStack> ctx, ServerPlayer player) throws CommandSyntaxException {
        NinjaData d = data(player);
        String natures = d.getNatures().isEmpty() ? "-" : d.getNatures().stream().map(ChakraNature::id).collect(Collectors.joining(", "));
        String jutsu = d.learnedJutsu().stream().map(Jutsu::id).collect(Collectors.joining(", "));
        MutableComponent msg = Component.literal("")
                .append(Component.literal(player.getGameProfile().getName()).withStyle(ChatFormatting.GOLD))
                .append(Component.literal("\nClan: ")).append(d.getClan().displayName())
                .append(Component.literal("\nAffinity: ")).append(d.getAffinity().displayName())
                .append(Component.literal(d.isAffinityRevealed() ? "" : " (hidden)"))
                .append(Component.literal("\nNatures: " + natures))
                .append(Component.literal(String.format("\nChakra: %d / %d (trained +%d)", (int) d.getChakra(), (int) d.maxChakra(), (int) d.getTrained())))
                .append(Component.literal("\nJutsu: " + (jutsu.isEmpty() ? "-" : jutsu)));
        ctx.getSource().sendSuccess(() -> msg, false);
        return 1;
    }

    private static int setClan(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        Clan clan = Clan.byId(StringArgumentType.getString(ctx, "clan"));
        if (clan == null) {
            ctx.getSource().sendFailure(Component.literal("Unknown clan. Options: none, uchiha, hyuga, uzumaki, nara"));
            return 0;
        }
        NinjaData d = data(player);
        d.setClan(clan);
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal(player.getGameProfile().getName() + " is now of the ").append(clan.displayName()).append(" clan"), true);
        return 1;
    }

    private static int unlockNature(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        ChakraNature nature = ChakraNature.byId(StringArgumentType.getString(ctx, "nature"));
        if (nature == null || !nature.isElement()) {
            ctx.getSource().sendFailure(Component.literal("Unknown nature. Options: fire, water, wind, lightning, earth"));
            return 0;
        }
        NinjaData d = data(player);
        d.revealAffinity();
        d.unlockNature(nature);
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Unlocked ").append(nature.displayName()).append(" for " + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int learn(CommandContext<CommandSourceStack> ctx, boolean learn) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        String id = StringArgumentType.getString(ctx, "jutsu");
        NinjaData d = data(player);
        if (id.equals("all")) {
            for (Jutsu j : Jutsus.all()) {
                if (learn) d.learn(j.id());
                else d.forget(j.id());
            }
        } else {
            Jutsu j = Jutsus.get(id);
            if (j == null) {
                ctx.getSource().sendFailure(Component.literal("Unknown jutsu: " + id));
                return 0;
            }
            if (learn) d.learn(j.id());
            else d.forget(j.id());
        }
        d.setSelected(d.getSelected());
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal((learn ? "Taught " : "Removed ") + id + (learn ? " to " : " from ") + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int training(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        float amount = FloatArgumentType.getFloat(ctx, "amount");
        NinjaData d = data(player);
        d.setTrained(amount);
        d.setChakra(d.getChakra());
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Max chakra of " + player.getGameProfile().getName() + " is now " + (int) d.maxChakra()), true);
        return 1;
    }

    private static int refill(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        NinjaData d = data(player);
        d.setChakra(d.maxChakra());
        for (Jutsu j : Jutsus.all()) d.setCooldown(j.id(), 0);
        ModNetwork.sync(player);
        ctx.getSource().sendSuccess(() -> Component.literal("Refilled " + player.getGameProfile().getName()), true);
        return 1;
    }

    private static int reset(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer player = EntityArgument.getPlayer(ctx, "player");
        NinjaData d = data(player);
        d.init(player.getRandom());
        ModNetwork.sync(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.welcome.clan", d.getClan().displayName()).withStyle(ChatFormatting.GOLD));
        ctx.getSource().sendSuccess(() -> Component.literal("Reset " + player.getGameProfile().getName()), true);
        return 1;
    }
}
