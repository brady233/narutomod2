package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;

import javax.annotation.Nullable;

/**
 * One technique. The {@link Action} does the actual work on the server and returns false
 * if the jutsu fizzled (no target, no room...), in which case no chakra or cooldown is spent.
 */
public final class Jutsu {
    @FunctionalInterface
    public interface Action {
        boolean perform(ServerPlayer player, NinjaData data);
    }

    private final String id;
    private final ChakraNature nature;
    @Nullable
    private final Clan clan;
    private final int tier;
    private final float cost;
    private final int cooldown;
    private final boolean needsDojutsu;
    private final Action action;

    Jutsu(String id, ChakraNature nature, @Nullable Clan clan, int tier, float cost, int cooldownTicks, boolean needsDojutsu, Action action) {
        this.id = id;
        this.nature = nature;
        this.clan = clan;
        this.tier = tier;
        this.cost = cost;
        this.cooldown = cooldownTicks;
        this.needsDojutsu = needsDojutsu;
        this.action = action;
    }

    public String id() {
        return id;
    }

    public ChakraNature nature() {
        return nature;
    }

    /** Clan that is allowed to learn this jutsu, or null if anyone can. */
    @Nullable
    public Clan clan() {
        return clan;
    }

    public int tier() {
        return tier;
    }

    public float cost() {
        return cost;
    }

    public int cooldown() {
        return cooldown;
    }

    public boolean needsDojutsu() {
        return needsDojutsu;
    }

    public Action action() {
        return action;
    }

    /** Minimum max chakra needed to learn this from a scroll (when tier requirements are on). */
    public float requiredMaxChakra() {
        return switch (tier) {
            case 2 -> 120f;
            case 3 -> 160f;
            default -> 0f;
        };
    }

    /** Texture group for the scroll item: fire, water, wind, lightning, earth, basic or clan. */
    public String category() {
        if (clan != null) return "clan";
        return nature == ChakraNature.NONE ? "basic" : nature.id();
    }

    public MutableComponent displayName() {
        return Component.translatable("jutsu.shinobiarts." + id).withStyle(clan != null ? clan.color() : nature.color());
    }

    public MutableComponent description() {
        return Component.translatable("jutsu.shinobiarts." + id + ".desc");
    }
}
