package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.Clan;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.shinobiarts.ninja.ChakraNature.EARTH;
import static com.shinobiarts.ninja.ChakraNature.FIRE;
import static com.shinobiarts.ninja.ChakraNature.LIGHTNING;
import static com.shinobiarts.ninja.ChakraNature.NONE;
import static com.shinobiarts.ninja.ChakraNature.WATER;
import static com.shinobiarts.ninja.ChakraNature.WIND;

/**
 * Every jutsu in the mod. To add one: register it here, implement its effect in {@link JutsuEffects},
 * then add its name/description to en_us.json, a scroll item model and a scroll recipe.
 * Cooldowns are in ticks (20 ticks = 1 second).
 */
public final class Jutsus {
    private static final Map<String, Jutsu> BY_ID = new LinkedHashMap<>();
    private static final Collection<Jutsu> ALL = Collections.unmodifiableCollection(BY_ID.values());

    //                                       id                    nature     clan          tier cost  cooldown  needs eyes
    // Fire Release
    public static final Jutsu FIREBALL          = reg("fireball",          FIRE,      null,         1, 25,   60,  false, JutsuEffects::fireball);
    public static final Jutsu PHOENIX_FLOWER    = reg("phoenix_flower",    FIRE,      null,         2, 30,   80,  false, JutsuEffects::phoenixFlower);
    public static final Jutsu FIRE_ANNIHILATION = reg("fire_annihilation", FIRE,      null,         3, 60,  240,  false, JutsuEffects::fireAnnihilation);
    // Water Release
    public static final Jutsu WATER_BULLET      = reg("water_bullet",      WATER,     null,         1, 15,   25,  false, JutsuEffects::waterBullet);
    public static final Jutsu WATER_PRISON      = reg("water_prison",      WATER,     null,         2, 35,  300,  false, JutsuEffects::waterPrison);
    public static final Jutsu WATER_DRAGON      = reg("water_dragon",      WATER,     null,         3, 55,  200,  false, JutsuEffects::waterDragon);
    // Wind Release
    public static final Jutsu GALE_PALM         = reg("gale_palm",         WIND,      null,         1, 15,   30,  false, JutsuEffects::galePalm);
    public static final Jutsu VACUUM_BLADE      = reg("vacuum_blade",      WIND,      null,         2, 25,   60,  false, JutsuEffects::vacuumBlade);
    public static final Jutsu GREAT_BREAKTHROUGH= reg("great_breakthrough",WIND,      null,         3, 45,  200,  false, JutsuEffects::greatBreakthrough);
    // Lightning Release
    public static final Jutsu LIGHTNING_ARMOR   = reg("lightning_armor",   LIGHTNING, null,         1, 35,  600,  false, JutsuEffects::lightningArmor);
    public static final Jutsu CHIDORI           = reg("chidori",           LIGHTNING, null,         2, 40,  160,  false, JutsuEffects::chidori);
    public static final Jutsu THUNDER_STRIKE    = reg("thunder_strike",    LIGHTNING, null,         3, 50,  300,  false, JutsuEffects::thunderStrike);
    // Earth Release
    public static final Jutsu EARTH_WALL        = reg("earth_wall",        EARTH,     null,         1, 25,  200,  false, JutsuEffects::earthWall);
    public static final Jutsu ROCK_ARMOR        = reg("rock_armor",        EARTH,     null,         2, 30,  600,  false, JutsuEffects::rockArmor);
    public static final Jutsu EARTH_SPIKES      = reg("earth_spikes",      EARTH,     null,         3, 45,  100,  false, JutsuEffects::earthSpikes);
    // Non-elemental
    public static final Jutsu SUBSTITUTION      = reg("substitution",      NONE,      null,         1, 20,  300,  false, JutsuEffects::substitution);
    public static final Jutsu BODY_FLICKER      = reg("body_flicker",      NONE,      null,         1, 15,   60,  false, JutsuEffects::bodyFlicker);
    public static final Jutsu SHADOW_CLONE      = reg("shadow_clone",      NONE,      null,         2, 40,  400,  false, JutsuEffects::shadowClone);
    public static final Jutsu RASENGAN          = reg("rasengan",          NONE,      null,         3, 45,  200,  false, JutsuEffects::rasengan);
    // Clan techniques
    public static final Jutsu SHADOW_POSSESSION = reg("shadow_possession", NONE,      Clan.NARA,    2, 35,  300,  false, JutsuEffects::shadowPossession);
    public static final Jutsu PALM_ROTATION     = reg("palm_rotation",     NONE,      Clan.HYUGA,   2, 35,  200,  false, JutsuEffects::palmRotation);
    public static final Jutsu AMATERASU         = reg("amaterasu",         NONE,      Clan.UCHIHA,  3, 80, 1200,  true,  JutsuEffects::amaterasu);

    private static Jutsu reg(String id, ChakraNature nature, @Nullable Clan clan, int tier, float cost, int cooldown, boolean needsDojutsu, Jutsu.Action action) {
        Jutsu jutsu = new Jutsu(id, nature, clan, tier, cost, cooldown, needsDojutsu, action);
        if (BY_ID.put(id, jutsu) != null) throw new IllegalStateException("Duplicate jutsu id " + id);
        return jutsu;
    }

    @Nullable
    public static Jutsu get(String id) {
        return BY_ID.get(id);
    }

    public static Collection<Jutsu> all() {
        return ALL;
    }

    private Jutsus() {}
}
