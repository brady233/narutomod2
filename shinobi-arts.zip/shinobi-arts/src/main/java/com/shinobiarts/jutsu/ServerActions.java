package com.shinobiarts.jutsu;

import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;

/** Handles keybind actions sent by the client. */
public final class ServerActions {
    /** Chakra needed to switch on Sharingan/Byakugan. */
    public static final float DOJUTSU_MIN_CHAKRA = 5f;

    private ServerActions() {}

    public static void handle(ServerPlayer player, int action, int arg) {
        NinjaData data = NinjaData.get(player);
        if (data == null || !data.isInitialized()) return;
        switch (action) {
            case ActionPacket.CAST -> JutsuCaster.tryCast(player);
            case ActionPacket.NEXT -> select(player, data, data.getSelected() + 1, true);
            case ActionPacket.PREV -> select(player, data, data.getSelected() - 1, true);
            case ActionPacket.SELECT -> select(player, data, arg, false);
            case ActionPacket.DOJUTSU -> toggleDojutsu(player, data);
            case ActionPacket.CHARGE_START -> {
                if (!data.isCharging()) {
                    data.setCharging(true);
                    JutsuUtil.sound(player.level(), player.position(), SoundEvents.BEACON_AMBIENT, 0.8f, 1.6f);
                    ModNetwork.sync(player);
                }
            }
            case ActionPacket.CHARGE_STOP -> {
                if (data.isCharging()) {
                    data.setCharging(false);
                    ModNetwork.sync(player);
                }
            }
            default -> {
            }
        }
    }

    private static void select(ServerPlayer player, NinjaData data, int index, boolean wrap) {
        int size = data.learnedJutsu().size();
        if (size == 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.no_jutsu").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (wrap) data.cycle(index - data.getSelected());
        else data.setSelected(index);
        Jutsu selected = data.selectedJutsu();
        if (selected != null) player.displayClientMessage(selected.displayName(), true);
        ModNetwork.sync(player);
    }

    private static void toggleDojutsu(ServerPlayer player, NinjaData data) {
        Clan clan = data.getClan();
        if (!clan.hasDojutsu()) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.no_dojutsu").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (data.isDojutsuActive()) {
            data.setDojutsuActive(false);
            if (clan == Clan.HYUGA) player.removeEffect(MobEffects.NIGHT_VISION);
            player.displayClientMessage(Component.translatable("message.shinobiarts.dojutsu_off", clan.dojutsuName()), true);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.BEACON_DEACTIVATE, 0.6f, 1.8f);
        } else {
            if (data.getChakra() < DOJUTSU_MIN_CHAKRA && !player.getAbilities().instabuild) {
                player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                        (int) data.getChakra(), (int) DOJUTSU_MIN_CHAKRA).withStyle(ChatFormatting.RED), true);
                return;
            }
            data.setDojutsuActive(true);
            NinjaTicker.applyDojutsu(player, data);
            player.displayClientMessage(Component.translatable("message.shinobiarts.dojutsu_on", clan.dojutsuName()), true);
            JutsuUtil.sound(player.level(), player.position(), SoundEvents.BEACON_ACTIVATE, 0.6f, 1.8f);
        }
        ModNetwork.sync(player);
    }
}
